"""Inactive KWPJ Voice OS HTTP client for a future Kodi provider.

This module deliberately has no registration side effects.  Importing it does
not make KWPJ selectable and it never falls back to ElevenLabs.  It implements
the transport contract so that the provider can be tested before activation.
"""

from __future__ import unicode_literals

import hashlib
import ipaddress
import json
import math
import os
import re
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid
import wave

from speech import SpeechCancelled, SpeechError, SpeechResult
from text_normalizer import compress_for_economy, normalize_for_speech


PCM_CONTENT_TYPE = "audio/pcm; codec=pcm_s16le; rate=24000; channels=1"
PCM_FORMAT = "pcm_s16le_24000"
SAMPLE_RATE = 24000
SAMPLE_WIDTH = 2
CHANNELS = 1
MAX_AUDIO_BYTES = 64 * 1024 * 1024
MAX_JSON_BYTES = 1024 * 1024
MAX_ERROR_BYTES = 16 * 1024
MAX_REQUEST_TEXT_CHARS = 9000
MAX_TOTAL_TEXT_CHARS = 18000
CONTEXT_LIMIT = 2000
HEALTH_TIMEOUT = 3.0
METADATA_TIMEOUT = 8.0
MAX_SPEECH_TIMEOUT = 15.0
CACHE_NAMESPACE = "kwpj_voice_os_v1"
RETRYABLE_STATUSES = frozenset((408, 425, 429, 502, 503, 504))

_SAFE_ID_RE = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_SAFE_ERROR_CODE_RE = re.compile(r"\A[A-Z][A-Z0-9_]{0,63}\Z")
_SENTENCE_BREAK_RE = re.compile(r"[.!?\u2026](?=\s)", re.UNICODE)

_ERROR_MESSAGES = {
    "AUTH_REQUIRED": "Brak tokenu KWPJ Voice OS. Uzupełnij ustawienia usługi.",
    "AUTH_INVALID": "Token KWPJ Voice OS jest nieprawidłowy albo wygasł.",
    "PERMISSION_DENIED": "Token KWPJ Voice OS nie ma uprawnień do tej operacji.",
    "INVALID_ARGUMENT": "KWPJ Voice OS odrzucił nieprawidłowe dane syntezy.",
    "UNSUPPORTED_FORMAT": "KWPJ Voice OS nie obsługuje wymaganego formatu PCM.",
    "VOICE_NOT_FOUND": "Nie znaleziono wybranego głosu KWPJ.",
    "VOICE_NOT_READY": "Wybrany głos KWPJ jest chwilowo niedostępny.",
    "VOICE_RIGHTS_REVOKED": "Wybrany głos KWPJ nie jest dopuszczony do użycia.",
    "MODEL_NOT_READY": "Model KWPJ Voice OS nie jest jeszcze gotowy.",
    "TEXT_TOO_LONG": "Tekst jest zbyt długi dla KWPJ Voice OS.",
    "QUOTA_EXCEEDED": "Limit usługi KWPJ Voice OS został wykorzystany.",
    "RATE_LIMITED": "KWPJ Voice OS chwilowo ogranicza liczbę zapytań.",
    "NO_CAPACITY": "KWPJ Voice OS nie ma teraz wolnej mocy obliczeniowej.",
    "DEADLINE_EXCEEDED": "KWPJ Voice OS nie zdążył przygotować głosu.",
    "IDEMPOTENCY_CONFLICT": "Żądanie KWPJ koliduje z wcześniejszą syntezą.",
    "INVALID_RESPONSE": "KWPJ Voice OS zwrócił nieprawidłowy dźwięk.",
    "INTERNAL_ERROR": "KWPJ Voice OS jest chwilowo niedostępny.",
}


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Keep the validated origin from being replaced by a redirect."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        del req, fp, code, msg, headers, newurl
        return None


class _HttpFailure(Exception):
    def __init__(self, status, body=b"", content_type=""):
        super().__init__(status)
        self.status = int(status or 0)
        self.body = body if isinstance(body, bytes) else b""
        self.content_type = content_type or ""


def validate_base_url(value):
    """Return a canonical safe base URL or raise ``SpeechError``.

    Remote services require HTTPS.  Plain HTTP is intentionally limited to
    literal loopback addresses and the reserved localhost name; private LAN
    addresses are not silently trusted.
    """

    if not isinstance(value, str):
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")
    candidate = value.strip()
    if not candidate or any(ord(character) < 32 for character in candidate):
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")
    if "?" in candidate or "#" in candidate:
        raise SpeechError("Adres KWPJ Voice OS nie może zawierać zapytania ani fragmentu.")
    try:
        parsed = urllib.parse.urlsplit(candidate)
        port = parsed.port
    except (TypeError, ValueError):
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")
    scheme = parsed.scheme.casefold()
    hostname = parsed.hostname.casefold() if parsed.hostname else ""
    if (
        scheme not in ("http", "https")
        or not parsed.netloc
        or not hostname
        or parsed.username is not None
        or parsed.password is not None
        or "@" in parsed.netloc
        or parsed.query
        or parsed.fragment
    ):
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")
    try:
        hostname.encode("ascii", "strict")
    except UnicodeEncodeError:
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")

    is_loopback = hostname == "localhost" or hostname.endswith(".localhost")
    if not is_loopback:
        try:
            is_loopback = ipaddress.ip_address(hostname).is_loopback
        except ValueError:
            is_loopback = False
    if scheme == "http" and not is_loopback:
        raise SpeechError("Zdalny KWPJ Voice OS wymaga bezpiecznego połączenia HTTPS.")

    path = parsed.path or ""
    if "\\" in path:
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")
    decoded_segments = urllib.parse.unquote(path).split("/")
    if any(segment in (".", "..") for segment in decoded_segments):
        raise SpeechError("Nieprawidłowy adres KWPJ Voice OS.")
    path = path.rstrip("/")
    host_for_url = "[%s]" % hostname if ":" in hostname else hostname
    netloc = host_for_url if port is None else "%s:%d" % (host_for_url, port)
    return urllib.parse.urlunsplit((scheme, netloc, path, "", ""))


def _header_value(headers, name):
    if headers is None:
        return ""
    try:
        value = headers.get(name)
    except (AttributeError, KeyError, TypeError):
        value = None
    if value is None:
        try:
            for key, item in headers.items():
                if str(key).casefold() == name.casefold():
                    value = item
                    break
        except (AttributeError, TypeError, ValueError):
            value = None
    return str(value).strip() if value is not None else ""


def _is_json_content_type(value):
    return value.split(";", 1)[0].strip().casefold() == "application/json"


def _is_strict_pcm_content_type(value):
    parts = [part.strip() for part in value.casefold().split(";")]
    if not parts or parts[0] != "audio/pcm":
        return False
    parameters = {}
    for part in parts[1:]:
        if "=" not in part:
            return False
        key, raw_value = (item.strip() for item in part.split("=", 1))
        if not key or key in parameters:
            return False
        parameters[key] = raw_value.strip('"')
    return parameters == {
        "codec": "pcm_s16le",
        "rate": "24000",
        "channels": "1",
    }


def _loads_json_object(body):
    if not isinstance(body, bytes) or len(body) > MAX_JSON_BYTES:
        raise ValueError("invalid JSON body")

    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result

    def reject_constant(_value):
        raise ValueError("invalid JSON number")

    payload = json.loads(
        body.decode("utf-8", "strict"),
        object_pairs_hook=unique_object,
        parse_constant=reject_constant,
    )
    if not isinstance(payload, dict):
        raise ValueError("JSON response is not an object")
    return payload


def _safe_error_code(body, content_type):
    if not _is_json_content_type(content_type):
        return ""
    try:
        payload = _loads_json_object(body)
        error = payload.get("error")
        code = error.get("code") if isinstance(error, dict) else ""
    except (AttributeError, TypeError, ValueError, UnicodeError):
        return ""
    if isinstance(code, str) and _SAFE_ERROR_CODE_RE.fullmatch(code):
        return code
    return ""


def _speech_error_for_http(failure):
    status = failure.status
    code = _safe_error_code(failure.body, failure.content_type)
    message = _ERROR_MESSAGES.get(code)
    if not message:
        if status == 401:
            message = _ERROR_MESSAGES["AUTH_INVALID"]
        elif status == 403:
            message = _ERROR_MESSAGES["PERMISSION_DENIED"]
        elif status == 413:
            message = _ERROR_MESSAGES["TEXT_TOO_LONG"]
        elif status == 429:
            message = _ERROR_MESSAGES["RATE_LIMITED"]
        elif status in (502, 503, 504) or status >= 500:
            message = "KWPJ Voice OS jest chwilowo niedostępny."
        else:
            message = "Nie udało się wykonać żądania KWPJ Voice OS (HTTP %s)." % status
    return SpeechError(message, status=status, retryable=status in RETRYABLE_STATUSES)


def _clamped_speed_percent(value):
    try:
        value = int(round(float(value)))
    except (TypeError, ValueError, OverflowError):
        value = 95
    return max(70, min(120, value))


def _split_text(text):
    remaining = text.strip()
    chunks = []
    while len(remaining) > MAX_REQUEST_TEXT_CHARS:
        sentence_cut = 0
        for match in _SENTENCE_BREAK_RE.finditer(
            remaining, 0, MAX_REQUEST_TEXT_CHARS
        ):
            sentence_cut = match.end()
        word_cut = remaining.rfind(" ", 0, MAX_REQUEST_TEXT_CHARS + 1)
        if sentence_cut >= MAX_REQUEST_TEXT_CHARS // 2:
            cut = sentence_cut
        elif word_cut > 0:
            cut = word_cut
        else:
            cut = MAX_REQUEST_TEXT_CHARS
        chunk = remaining[:cut].strip()
        if not chunk:
            chunk = remaining[:MAX_REQUEST_TEXT_CHARS]
            cut = MAX_REQUEST_TEXT_CHARS
        chunks.append(chunk)
        remaining = remaining[cut:].strip()
    if remaining:
        chunks.append(remaining)
    return chunks


class KWPJVoiceClient(object):
    """Strict stdlib client kept inactive until the provider is approved."""

    def __init__(
        self,
        base_url,
        token,
        voice_id,
        model_id,
        cache_dir,
        timeout=MAX_SPEECH_TIMEOUT,
        speech_speed_percent=95,
        opener=None,
    ):
        self.base_url = validate_base_url(base_url)
        self.token = token.strip() if isinstance(token, str) else ""
        if any(ord(character) < 32 for character in self.token) or len(self.token) > 4096:
            self.token = ""
        self.voice_id = voice_id.strip() if isinstance(voice_id, str) else ""
        self.model_id = model_id.strip() if isinstance(model_id, str) else ""
        self.cache_dir = cache_dir
        try:
            requested_timeout = float(timeout)
        except (TypeError, ValueError, OverflowError):
            requested_timeout = MAX_SPEECH_TIMEOUT
        if not math.isfinite(requested_timeout) or requested_timeout <= 0:
            requested_timeout = MAX_SPEECH_TIMEOUT
        self.speech_timeout = min(requested_timeout, MAX_SPEECH_TIMEOUT)
        self.speech_speed_percent = _clamped_speed_percent(speech_speed_percent)
        if opener is None:
            opener = urllib.request.build_opener(_NoRedirectHandler()).open
        self._opener = opener

    @property
    def cache_namespace(self):
        return os.path.join(self.cache_dir, CACHE_NAMESPACE)

    def _require_token(self):
        if not self.token:
            raise SpeechError(_ERROR_MESSAGES["AUTH_REQUIRED"])

    def _url(self, path):
        return self.base_url + path

    @staticmethod
    def _cancelled(cancelled):
        return callable(cancelled) and bool(cancelled())

    def _open(self, request, timeout):
        opener = self._opener.open if hasattr(self._opener, "open") else self._opener
        return opener(request, timeout=timeout)

    @staticmethod
    def _read_accepted_body(response, headers, max_bytes):
        content_length = _header_value(headers, "Content-Length")
        expected_length = None
        if content_length:
            try:
                expected_length = int(content_length)
            except ValueError:
                raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową odpowiedź.")
            if expected_length < 0 or expected_length > max_bytes:
                raise SpeechError("Odpowiedź KWPJ Voice OS jest zbyt duża.")
        body = response.read(max_bytes + 1)
        if not isinstance(body, bytes):
            raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową odpowiedź.")
        if len(body) > max_bytes:
            raise SpeechError("Odpowiedź KWPJ Voice OS jest zbyt duża.")
        if expected_length is not None and len(body) != expected_length:
            raise SpeechError("KWPJ Voice OS zwrócił niepełną odpowiedź.")
        return body

    def _single_attempt(self, request, timeout, max_bytes, accepted_statuses):
        response = None
        try:
            response = self._open(request, timeout)
            status = getattr(response, "status", None)
            if status is None and hasattr(response, "getcode"):
                status = response.getcode()
            status = int(status or 0)
            headers = getattr(response, "headers", None)
            content_type = _header_value(headers, "Content-Type")
            if status not in accepted_statuses:
                body = response.read(MAX_ERROR_BYTES + 1)
                raise _HttpFailure(status, body[:MAX_ERROR_BYTES], content_type)
            body = self._read_accepted_body(response, headers, max_bytes)
            return body, content_type, headers, status
        except urllib.error.HTTPError as exc:
            headers = getattr(exc, "headers", None)
            content_type = _header_value(headers, "Content-Type")
            if exc.code in accepted_statuses:
                try:
                    body = self._read_accepted_body(exc, headers, max_bytes)
                    return body, content_type, headers, int(exc.code)
                finally:
                    try:
                        exc.close()
                    except Exception:
                        pass
            try:
                body = exc.read(MAX_ERROR_BYTES + 1)[:MAX_ERROR_BYTES]
            except Exception:
                body = b""
            finally:
                try:
                    exc.close()
                except Exception:
                    pass
            raise _HttpFailure(exc.code, body, content_type)
        finally:
            if response is not None and hasattr(response, "close"):
                try:
                    response.close()
                except Exception:
                    pass

    def _perform(
        self,
        method,
        path,
        timeout,
        accept,
        data=None,
        idempotency_key=None,
        cancelled=None,
        max_bytes=MAX_JSON_BYTES,
        authenticated=True,
        accepted_statuses=(200,),
        allow_retry=True,
    ):
        if authenticated:
            self._require_token()
        attempts = 2 if allow_retry else 1
        for attempt in range(attempts):
            if self._cancelled(cancelled):
                raise SpeechCancelled()
            headers = {"Accept": accept, "X-Request-Id": "kodi_%s" % uuid.uuid4().hex}
            if authenticated:
                headers["Authorization"] = "Bearer %s" % self.token
            if data is not None:
                headers["Content-Type"] = "application/json; charset=utf-8"
            if idempotency_key:
                headers["Idempotency-Key"] = idempotency_key
            request = urllib.request.Request(
                self._url(path),
                data=data,
                headers=headers,
                method=method,
            )
            try:
                return self._single_attempt(
                    request, timeout, max_bytes, frozenset(accepted_statuses)
                )
            except _HttpFailure as failure:
                if self._cancelled(cancelled):
                    raise SpeechCancelled()
                if (
                    attempt == 0
                    and allow_retry
                    and failure.status in RETRYABLE_STATUSES
                ):
                    continue
                raise _speech_error_for_http(failure)
            except SpeechError:
                raise
            except (urllib.error.URLError, OSError, TimeoutError):
                if attempt == 0 and not self._cancelled(cancelled):
                    continue
                if self._cancelled(cancelled):
                    raise SpeechCancelled()
                raise SpeechError(
                    "Brak połączenia z KWPJ Voice OS.",
                    status=0,
                    retryable=True,
                )
        raise SpeechError("Brak połączenia z KWPJ Voice OS.", retryable=True)

    def _request_json(
        self,
        path,
        timeout,
        authenticated=True,
        accepted_statuses=(200,),
        allow_retry=True,
        with_status=False,
    ):
        body, content_type, _headers, status = self._perform(
            "GET",
            path,
            timeout,
            "application/json",
            max_bytes=MAX_JSON_BYTES,
            authenticated=authenticated,
            accepted_statuses=accepted_statuses,
            allow_retry=allow_retry,
        )
        if not _is_json_content_type(content_type):
            raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową odpowiedź.")
        try:
            payload = _loads_json_object(body)
        except (TypeError, ValueError, UnicodeError):
            raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową odpowiedź.")
        return (payload, status) if with_status else payload

    def health(self):
        payload, status = self._request_json(
            "/health",
            HEALTH_TIMEOUT,
            authenticated=False,
            accepted_statuses=(200, 503),
            allow_retry=False,
            with_status=True,
        )
        formats = payload.get("formats")
        if (
            payload.get("service") != "kwpj-voice-os"
            or payload.get("api_version") != "v1"
            or not isinstance(payload.get("tts_ready"), bool)
            or not isinstance(formats, list)
            or PCM_FORMAT not in formats
            or (status == 503 and payload.get("tts_ready") is not False)
        ):
            raise SpeechError("KWPJ Voice OS zwrócił nieprawidłowy status usługi.")
        return payload

    def list_voices(self):
        self._require_token()
        voices = {}
        page_token = ""
        seen_tokens = set()
        for _page in range(20):
            query = {"page_size": 100}
            if page_token:
                query["page_token"] = page_token
            path = "/v1/voices?%s" % urllib.parse.urlencode(query)
            payload = self._request_json(path, METADATA_TIMEOUT)
            items = payload.get("voices")
            next_token = payload.get("next_page_token")
            if not isinstance(items, list) or not (
                next_token is None or isinstance(next_token, str)
            ):
                raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową listę głosów.")
            for item in items:
                if not isinstance(item, dict):
                    raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową listę głosów.")
                voice_id = item.get("id")
                name = item.get("name")
                voice_version = item.get("voice_version")
                styles = item.get("styles")
                models = item.get("models")
                if (
                    not isinstance(voice_id, str)
                    or not _SAFE_ID_RE.fullmatch(voice_id)
                    or not isinstance(name, str)
                    or not name.strip()
                    or not isinstance(voice_version, str)
                    or not _SAFE_ID_RE.fullmatch(voice_version)
                    or item.get("language") != "pl-PL"
                    or item.get("rights_status") != "verified"
                    or item.get("status") != "active"
                    or not isinstance(styles, list)
                    or not styles
                    or any(not isinstance(value, str) or not value for value in styles)
                    or not isinstance(models, list)
                    or not models
                    or any(
                        not isinstance(value, str) or not _SAFE_ID_RE.fullmatch(value)
                        for value in models
                    )
                    or voice_id in voices
                ):
                    raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową listę głosów.")
                voices[voice_id] = (name.strip(), voice_id, "KWPJ")
            page_token = (next_token or "").strip()
            if not page_token:
                break
            if page_token in seen_tokens or len(page_token) > 256:
                raise SpeechError("KWPJ Voice OS zwrócił nieprawidłową listę głosów.")
            seen_tokens.add(page_token)
        else:
            raise SpeechError("Lista głosów KWPJ ma zbyt wiele stron.")
        return sorted(voices.values(), key=lambda value: value[0].casefold())

    def usage(self):
        payload = self._request_json("/v1/usage", METADATA_TIMEOUT)
        metering = payload.get("metering")
        invalid = SpeechError("KWPJ Voice OS zwrócił nieprawidłowe dane użycia.")
        if (
            metering not in ("cloud_metered", "local_unlimited")
            or payload.get("unit") != "seconds"
            or not isinstance(payload.get("tier"), str)
            or not payload.get("tier").strip()
            or payload.get("status") not in ("active", "inactive", "suspended")
            or not isinstance(payload.get("overage_allowed"), bool)
        ):
            raise invalid
        used = payload.get("used")
        if isinstance(used, bool) or not isinstance(used, int) or used < 0:
            raise invalid
        limit = payload.get("limit")
        remaining = payload.get("remaining")
        period_ends_at = payload.get("period_ends_at")
        if metering == "local_unlimited":
            if (
                limit is not None
                or remaining is not None
                or period_ends_at is not None
                or payload.get("overage_allowed") is not False
            ):
                raise invalid
        elif (
            isinstance(limit, bool)
            or not isinstance(limit, int)
            or limit < 0
            or isinstance(remaining, bool)
            or not isinstance(remaining, int)
            or remaining < 0
            or remaining != max(0, limit - used)
            or not isinstance(period_ends_at, str)
            or not period_ends_at.strip()
        ):
            raise invalid
        return payload

    def _canonical_payload_bytes(self, payload):
        return json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")

    def _idempotency_key(self, payload):
        material = self.base_url.encode("utf-8") + b"\0" + self._canonical_payload_bytes(payload)
        return "kodi-%s" % hashlib.sha256(material).hexdigest()

    def _cache_path(self, text, previous_text, next_text, economy_mode, deadline_ms):
        signature = {
            "provider": "kwpj-voice-os-v1",
            "base_url": self.base_url,
            "voice": self.voice_id,
            "model": self.model_id,
            "response_format": PCM_FORMAT,
            "speed": self.speech_speed_percent / 100.0,
            "input": text,
            "previous_text": previous_text,
            "next_text": next_text,
            "economy_mode": bool(economy_mode),
            "deadline_ms": deadline_ms,
        }
        digest = hashlib.sha256(self._canonical_payload_bytes(signature)).hexdigest()
        return os.path.join(self.cache_namespace, digest + ".wav")

    def _request_pcm(self, payload, cancelled, max_bytes):
        body = self._canonical_payload_bytes(payload)
        idempotency_key = self._idempotency_key(payload)
        pcm, content_type, headers, _status = self._perform(
            "POST",
            "/v1/audio/speech",
            self.speech_timeout,
            PCM_CONTENT_TYPE,
            data=body,
            idempotency_key=idempotency_key,
            cancelled=cancelled,
            max_bytes=max_bytes,
        )
        if not _is_strict_pcm_content_type(content_type):
            raise SpeechError(_ERROR_MESSAGES["INVALID_RESPONSE"])
        if not pcm or len(pcm) % (CHANNELS * SAMPLE_WIDTH):
            raise SpeechError(_ERROR_MESSAGES["INVALID_RESPONSE"])
        synthetic = _header_value(headers, "X-KWPJ-Synthetic-Audio")
        voice_version = _header_value(headers, "X-KWPJ-Voice-Version")
        model_version = _header_value(headers, "X-KWPJ-Model-Version")
        duration = _header_value(headers, "X-KWPJ-Audio-Duration-Ms")
        if (
            synthetic.casefold() != "true"
            or not _SAFE_ID_RE.fullmatch(voice_version)
            or not _SAFE_ID_RE.fullmatch(model_version)
        ):
            raise SpeechError(_ERROR_MESSAGES["INVALID_RESPONSE"])
        expected_duration = max(1, int(math.ceil((len(pcm) // 2) * 1000.0 / SAMPLE_RATE)))
        try:
            if int(duration) != expected_duration:
                raise ValueError("duration mismatch")
        except (TypeError, ValueError):
            raise SpeechError(_ERROR_MESSAGES["INVALID_RESPONSE"])
        return pcm, voice_version, model_version

    def synthesize(
        self,
        text,
        previous_text="",
        next_text="",
        economy_mode=False,
        cancelled=None,
        deadline_ms=None,
    ):
        self._require_token()
        text = compress_for_economy(text) if economy_mode else normalize_for_speech(text)
        if economy_mode:
            previous_text = ""
            next_text = ""
        else:
            previous_text = normalize_for_speech(previous_text)[-CONTEXT_LIMIT:]
            next_text = normalize_for_speech(next_text)[:CONTEXT_LIMIT]
        if not text:
            raise SpeechError("Brak tekstu do przeczytania.")
        if len(text) > MAX_TOTAL_TEXT_CHARS:
            raise SpeechError("Pojedyncza kwestia jest zbyt długa dla KWPJ Voice OS.")
        if not _SAFE_ID_RE.fullmatch(self.voice_id):
            raise SpeechError("Brak prawidłowego identyfikatora głosu KWPJ.")
        if not _SAFE_ID_RE.fullmatch(self.model_id):
            raise SpeechError("Brak prawidłowego identyfikatora modelu KWPJ.")
        if deadline_ms is not None and (
            isinstance(deadline_ms, bool)
            or not isinstance(deadline_ms, int)
            or not 1 <= deadline_ms <= 15000
        ):
            raise SpeechError("Nieprawidłowy limit czasu syntezy KWPJ.")
        if not self.cache_dir:
            raise SpeechError("Brak katalogu na pliki głosu KWPJ.")

        os.makedirs(self.cache_namespace, exist_ok=True)
        path = self._cache_path(
            text, previous_text, next_text, economy_mode, deadline_ms
        )
        chunks = _split_text(text)
        temporary_fd, temporary = tempfile.mkstemp(
            prefix=".kwpj-", suffix=".part", dir=self.cache_namespace
        )
        os.close(temporary_fd)
        pcm_bytes = 0
        response_versions = None
        try:
            with wave.open(temporary, "wb") as output:
                output.setnchannels(CHANNELS)
                output.setsampwidth(SAMPLE_WIDTH)
                output.setframerate(SAMPLE_RATE)
                for index, chunk in enumerate(chunks):
                    if self._cancelled(cancelled):
                        raise SpeechCancelled()
                    payload = {
                        "input": chunk,
                        "voice": self.voice_id,
                        "model": self.model_id,
                        "response_format": PCM_FORMAT,
                        "speed": self.speech_speed_percent / 100.0,
                    }
                    chunk_previous = (
                        previous_text
                        if index == 0
                        else chunks[index - 1][-CONTEXT_LIMIT:]
                    )
                    chunk_next = (
                        next_text
                        if index == len(chunks) - 1
                        else chunks[index + 1][:CONTEXT_LIMIT]
                    )
                    if chunk_previous:
                        payload["previous_text"] = chunk_previous
                    if chunk_next:
                        payload["next_text"] = chunk_next
                    if deadline_ms is not None:
                        payload["deadline_ms"] = deadline_ms
                    remaining = MAX_AUDIO_BYTES - pcm_bytes
                    if remaining <= 0:
                        raise SpeechError("Odpowiedź KWPJ Voice OS jest zbyt duża.")
                    pcm, voice_version, model_version = self._request_pcm(
                        payload, cancelled, remaining
                    )
                    if self._cancelled(cancelled):
                        raise SpeechCancelled()
                    versions = (voice_version, model_version)
                    if response_versions is None:
                        response_versions = versions
                    elif response_versions != versions:
                        raise SpeechError(_ERROR_MESSAGES["INVALID_RESPONSE"])
                    output.writeframesraw(pcm)
                    pcm_bytes += len(pcm)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass
        self.prune_cache(128)
        return SpeechResult(path, (pcm_bytes // 2) / float(SAMPLE_RATE), False)

    def prune_cache(self, keep):
        try:
            files = [
                os.path.join(self.cache_namespace, name)
                for name in os.listdir(self.cache_namespace)
                if name.endswith(".wav")
            ]
            files.sort(key=lambda item: os.path.getmtime(item), reverse=True)
            for path in files[max(0, int(keep)) :]:
                try:
                    os.remove(path)
                except OSError:
                    pass
        except (OSError, TypeError, ValueError):
            pass


# Both spellings are exported for future adapter code without activating it.
KwpjVoiceClient = KWPJVoiceClient
KWPJVoiceOSClient = KWPJVoiceClient
